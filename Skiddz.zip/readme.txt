🔻 1. Open "SkiddzExecutor.exe";
🔻 2. Click "Inject", after starting the game, the cheat is automatically started;
🔻 3. Open menu key - "Del";
🔻 4. Have a nice game, don't forget to like my video!